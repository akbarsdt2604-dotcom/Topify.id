const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "6289517579659@s.whatsapp.net"
  global.kontakOwner = "6289517579659"
  global.namaStore = "Topify.id"
  global.botName = "Topify Bot"
  global.ownerName = "akbarsyhdt"
  
  
  global.linkyt = "-_-"
  global.linkig = "-_-" 
  global.dana = "-" 
  global.ovo = "-"
  global.gopay = "-" 
  global.sawer = "Link saweria mu" 
 global.linkgc1 = "-"
 global.linkgc2 = "—"
//Jikalau dari salah satu di atas kalian tidak memiliki 
//silahkan kosongkan atau isi --


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})